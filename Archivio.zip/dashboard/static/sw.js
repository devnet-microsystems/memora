const CACHE_NAME = 'memora-cache-v1';
const STATIC_ASSETS = [
  '/patient',
  '/static/manifest.json',
  '/static/icon-192.svg',
  '/static/icon-512.svg'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Do not cache API calls
  if (event.request.url.includes('/api/')) {
    return;
  }
  
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});

self.addEventListener('push', (event) => {
  let data = {title: "Memora Alert", body: "New anomaly detected"};
  if (event.data) {
    data = event.data.json();
  }
  const options = {
    body: data.body,
    icon: '/static/icon-192.svg',
    badge: '/static/icon-192.svg'
  };
  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});
